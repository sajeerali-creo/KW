<?php
/* Template Name: coming soon */
?>
<?php get_header(); ?>

<?php get_footer(); ?>